"""
Student Expense Tracker
A beginner-friendly desktop application using Tkinter and SQLite.

Run:
    python expense_tracker.py

The database file (expenses.db) is created automatically in this folder.
"""

import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date

DATABASE_NAME = "expenses.db"


def create_database():
    """Create the expenses table if it does not already exist."""
    connection = sqlite3.connect(DATABASE_NAME)
    cursor = connection.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            expense_date TEXT NOT NULL,
            category TEXT NOT NULL,
            description TEXT,
            amount REAL NOT NULL
        )
    """)
    connection.commit()
    connection.close()


def add_expense(expense_date, category, description, amount):
    """Save one expense in the database."""
    connection = sqlite3.connect(DATABASE_NAME)
    cursor = connection.cursor()
    cursor.execute(
        """INSERT INTO expenses (expense_date, category, description, amount)
           VALUES (?, ?, ?, ?)""",
        (expense_date, category, description, amount)
    )
    connection.commit()
    connection.close()


def get_all_expenses():
    """Return all expenses, newest first."""
    connection = sqlite3.connect(DATABASE_NAME)
    cursor = connection.cursor()
    cursor.execute("""
        SELECT id, expense_date, category, description, amount
        FROM expenses
        ORDER BY expense_date DESC, id DESC
    """)
    rows = cursor.fetchall()
    connection.close()
    return rows


def delete_expense(expense_id):
    """Delete an expense using its ID."""
    connection = sqlite3.connect(DATABASE_NAME)
    cursor = connection.cursor()
    cursor.execute("DELETE FROM expenses WHERE id = ?", (expense_id,))
    connection.commit()
    connection.close()


class ExpenseTracker:
    def __init__(self, root):
        self.root = root
        self.root.title("Student Expense Tracker")
        self.root.geometry("850x600")
        self.root.minsize(760, 520)
        self.root.configure(bg="#f2f5f9")

        self.setup_style()
        self.create_widgets()
        self.load_expenses()

    def setup_style(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(
            "Treeview",
            rowheight=28,
            font=("Arial", 10),
            background="white",
            fieldbackground="white"
        )
        style.configure(
            "Treeview.Heading",
            font=("Arial", 10, "bold"),
            background="#dce6f1"
        )
        style.configure("TCombobox", padding=5)

    def create_widgets(self):
        heading = tk.Label(
            self.root,
            text="Student Expense Tracker",
            font=("Arial", 22, "bold"),
            bg="#f2f5f9",
            fg="#203864"
        )
        heading.pack(pady=(18, 4))

        subtitle = tk.Label(
            self.root,
            text="Record and manage your daily expenses",
            font=("Arial", 10),
            bg="#f2f5f9",
            fg="#555555"
        )
        subtitle.pack(pady=(0, 14))

        # Form area
        form = tk.LabelFrame(
            self.root,
            text=" Add New Expense ",
            font=("Arial", 11, "bold"),
            bg="white",
            fg="#203864",
            padx=12,
            pady=10
        )
        form.pack(fill="x", padx=20, pady=5)

        tk.Label(form, text="Date (YYYY-MM-DD)", bg="white").grid(
            row=0, column=0, sticky="w", padx=5, pady=5
        )
        self.date_entry = tk.Entry(form, width=18, font=("Arial", 10))
        self.date_entry.grid(row=1, column=0, padx=5, pady=3, sticky="w")
        self.date_entry.insert(0, date.today().isoformat())

        tk.Label(form, text="Category", bg="white").grid(
            row=0, column=1, sticky="w", padx=5, pady=5
        )
        self.category_box = ttk.Combobox(
            form,
            values=["Food", "Travel", "Books", "College", "Shopping", "Other"],
            state="readonly",
            width=17
        )
        self.category_box.grid(row=1, column=1, padx=5, pady=3, sticky="w")
        self.category_box.set("Food")

        tk.Label(form, text="Description", bg="white").grid(
            row=0, column=2, sticky="w", padx=5, pady=5
        )
        self.description_entry = tk.Entry(form, width=24, font=("Arial", 10))
        self.description_entry.grid(row=1, column=2, padx=5, pady=3, sticky="w")

        tk.Label(form, text="Amount (₹)", bg="white").grid(
            row=0, column=3, sticky="w", padx=5, pady=5
        )
        self.amount_entry = tk.Entry(form, width=14, font=("Arial", 10))
        self.amount_entry.grid(row=1, column=3, padx=5, pady=3, sticky="w")

        add_button = tk.Button(
            form,
            text="Add Expense",
            command=self.handle_add_expense,
            bg="#203864",
            fg="white",
            activebackground="#31558a",
            activeforeground="white",
            font=("Arial", 10, "bold"),
            padx=12,
            pady=7,
            relief="flat",
            cursor="hand2"
        )
        add_button.grid(row=1, column=4, padx=10)

        # Expense table
        table_frame = tk.LabelFrame(
            self.root,
            text=" Expense Records ",
            font=("Arial", 11, "bold"),
            bg="white",
            fg="#203864",
            padx=10,
            pady=10
        )
        table_frame.pack(fill="both", expand=True, padx=20, pady=12)

        columns = ("id", "date", "category", "description", "amount")
        self.tree = ttk.Treeview(
            table_frame,
            columns=columns,
            show="headings",
            selectmode="browse"
        )

        self.tree.heading("id", text="ID")
        self.tree.heading("date", text="Date")
        self.tree.heading("category", text="Category")
        self.tree.heading("description", text="Description")
        self.tree.heading("amount", text="Amount (₹)")

        self.tree.column("id", width=50, anchor="center")
        self.tree.column("date", width=120, anchor="center")
        self.tree.column("category", width=130, anchor="center")
        self.tree.column("description", width=260)
        self.tree.column("amount", width=120, anchor="e")

        scrollbar = ttk.Scrollbar(
            table_frame, orient="vertical", command=self.tree.yview
        )
        self.tree.configure(yscrollcommand=scrollbar.set)

        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Bottom controls and total
        bottom = tk.Frame(self.root, bg="#f2f5f9")
        bottom.pack(fill="x", padx=20, pady=(0, 15))

        self.total_label = tk.Label(
            bottom,
            text="Total Expenses: ₹0.00",
            font=("Arial", 13, "bold"),
            bg="#f2f5f9",
            fg="#203864"
        )
        self.total_label.pack(side="left")

        delete_button = tk.Button(
            bottom,
            text="Delete Selected",
            command=self.handle_delete_expense,
            bg="#b3261e",
            fg="white",
            activebackground="#8f1d17",
            activeforeground="white",
            font=("Arial", 10, "bold"),
            padx=12,
            pady=7,
            relief="flat",
            cursor="hand2"
        )
        delete_button.pack(side="right", padx=(8, 0))

        refresh_button = tk.Button(
            bottom,
            text="Refresh",
            command=self.load_expenses,
            bg="#477a55",
            fg="white",
            activebackground="#356341",
            activeforeground="white",
            font=("Arial", 10, "bold"),
            padx=12,
            pady=7,
            relief="flat",
            cursor="hand2"
        )
        refresh_button.pack(side="right")

    def handle_add_expense(self):
        expense_date = self.date_entry.get().strip()
        category = self.category_box.get().strip()
        description = self.description_entry.get().strip()
        amount_text = self.amount_entry.get().strip()

        # Check that the required fields are filled in.
        if not expense_date or not category or not amount_text:
            messagebox.showwarning(
                "Missing Information",
                "Please enter the date, category, and amount."
            )
            return

        # Check the date format.
        try:
            date.fromisoformat(expense_date)
        except ValueError:
            messagebox.showerror(
                "Invalid Date",
                "Enter the date in YYYY-MM-DD format, for example 2026-11-06."
            )
            return

        # Check that the amount is a positive number.
        try:
            amount = float(amount_text)
            if amount <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror(
                "Invalid Amount",
                "Please enter an amount greater than zero."
            )
            return

        add_expense(expense_date, category, description, amount)

        self.description_entry.delete(0, tk.END)
        self.amount_entry.delete(0, tk.END)
        self.load_expenses()
        messagebox.showinfo("Success", "Expense added successfully!")

    def load_expenses(self):
        # Remove old rows from the table before loading fresh records.
        for item in self.tree.get_children():
            self.tree.delete(item)

        expenses = get_all_expenses()
        total = 0.0

        for expense in expenses:
            expense_id, expense_date, category, description, amount = expense
            total += amount
            self.tree.insert(
                "",
                tk.END,
                values=(
                    expense_id,
                    expense_date,
                    category,
                    description or "-",
                    f"{amount:.2f}"
                )
            )

        self.total_label.config(text=f"Total Expenses: ₹{total:.2f}")

    def handle_delete_expense(self):
        selected_item = self.tree.selection()

        if not selected_item:
            messagebox.showwarning(
                "No Selection",
                "Please select an expense record to delete."
            )
            return

        values = self.tree.item(selected_item[0], "values")
        expense_id = int(values[0])

        answer = messagebox.askyesno(
            "Confirm Delete",
            "Are you sure you want to delete this expense?"
        )
        if answer:
            delete_expense(expense_id)
            self.load_expenses()
            messagebox.showinfo("Deleted", "Expense deleted successfully!")


if __name__ == "__main__":
    create_database()

    main_window = tk.Tk()
    app = ExpenseTracker(main_window)
    main_window.mainloop()
