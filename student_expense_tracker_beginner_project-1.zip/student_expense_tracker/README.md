# Student Expense Tracker

A simple beginner-friendly **desktop application** made with Python, Tkinter, and SQLite. It helps students record daily expenses and view the total amount spent.

## 1. Features

- Add an expense with date, category, description, and amount.
- View all saved expense records in a table.
- Delete a selected expense.
- Automatically calculate the total expenses.
- Save records in an SQLite database, so they remain available after closing the app.
- Validate dates and amounts before saving.

## 2. Technologies Used

- **Python 3** – main programming language.
- **Tkinter** – creates the desktop application's graphical interface.
- **SQLite3** – stores expense records in a local database.
- **ttk** – provides the table and dropdown widgets.
- **datetime** – checks dates and supplies today's date.

## 3. Project Folder Structure

After extracting or creating the project, the folder should look like this:

```text
student_expense_tracker/
│
├── expense_tracker.py
└── README.md
```

The program automatically creates `expenses.db` the first time it runs. You do not need to create that file yourself.

## 4. Requirements

- Python 3 installed on your computer.
- Tkinter (usually included with the standard Python installation on Windows).
- SQLite3 (included with Python; no separate database installation is needed).

No `pip install` command is required for this project.

## 5. How to Run the Project

1. Extract the project ZIP file.
2. Open the `student_expense_tracker` folder in Visual Studio Code.
3. Open the file named `expense_tracker.py`.
4. Open the VS Code terminal using **Terminal → New Terminal**.
5. Check that Python is installed:

   ```bash
   python --version
   ```

6. Run the program:

   ```bash
   python expense_tracker.py
   ```

A desktop window titled **Student Expense Tracker** should open.

> If the `python` command is not recognised on Windows, try `py expense_tracker.py`.

## 6. How to Use the Application

1. Enter the date in `YYYY-MM-DD` format. Today's date is filled in automatically.
2. Choose a category, such as Food, Travel, Books, College, Shopping, or Other.
3. Enter a short description, for example `Bus ticket`.
4. Enter the amount in rupees.
5. Click **Add Expense**.
6. The new record appears in the table and the total is updated.
7. To remove a record, select its row and click **Delete Selected**.
8. Click **Refresh** to reload the records from the database.

## 7. Database Design

The program creates a table named `expenses` inside `expenses.db`.

| Column | Purpose |
|---|---|
| `id` | Unique ID for each expense |
| `expense_date` | Date of the expense |
| `category` | Expense category |
| `description` | Short details about the expense |
| `amount` | Money spent |

The `id` column is the primary key and increases automatically.

## 8. Main Functions Explained

- `create_database()` – creates the database table if it does not exist.
- `add_expense()` – inserts a new expense into SQLite.
- `get_all_expenses()` – reads all expense records.
- `delete_expense()` – deletes a selected record using its ID.
- `create_widgets()` – builds the labels, input fields, buttons, and table.
- `handle_add_expense()` – checks the entered information and saves it.
- `load_expenses()` – displays records and calculates the total.
- `handle_delete_expense()` – deletes the selected record after confirmation.

## 9. Important Notes

- This is a **desktop application**, not a website. Tkinter creates windows on your computer.
- Keep `expense_tracker.py` and `expenses.db` in the same folder so the application can find its database.
- Do not delete `expenses.db` if you want to keep your saved expense records.
- The project is intended as a simple learning project. It does not include user accounts or cloud synchronisation.

## 10. Future Improvements

Possible improvements include monthly reports, category-wise totals, editing existing expenses, searching records, and exporting data to CSV.
